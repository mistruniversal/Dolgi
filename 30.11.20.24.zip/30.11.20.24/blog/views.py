from django.shortcuts import render
from .forms import ProfileForm

def profile(request):
    profile_form = ProfileForm()
    return render(request, 'profile.html', {'profile_form': profile_form})


from .forms import UserForm
from .models import User

def create_profile(request):
    if request.method == 'POST':
        user_form = UserForm(request.POST)
        if user_form.is_valid():
            user = User(
                name=user_form.cleaned_data['name'],
                age=user_form.cleaned_data['age'],
                phone=user_form.cleaned_data['phone'],
                email=user_form.cleaned_data['email']
            )
            user.save()
            return redirect('user_list')  # Переход на страницу списка пользователей
    else:
        user_form = UserForm()

    return render(request, 'create_profile.html', {'user_form': user_form})




def sort_users(request):
    field = request.GET.get('field', 'id')
    dir = request.GET.get('dir', 'up')

    if field not in ['id', 'name', 'age']:
        field = 'id'

    if dir not in ['up', 'dn']:
        dir = 'up'

    if dir == 'up':
        user_data = User.objects.all().order_by(field)
        sort_dir = 'возрастание'
    else:
        user_data = User.objects.all().order_by(f'-{field}')
        sort_dir = 'убывание'

    sort_field_mapping = {
        'id': 'id',
        'name': 'имени',
        'age': 'возрасту'
    }

    sort_field = sort_field_mapping.get(field, 'id')

    return render(request, 'sort_users.html', {
        'user_data': user_data,
        'sort_field': sort_field,
        'sort_dir': sort_dir,
    })

from django.shortcuts import render
from django.http import HttpResponse, HttpResponseRedirect, HttpResponsePermanentRedirect, HttpResponseNotFound, \
    HttpResponseBadRequest, HttpResponseForbidden


# Create your views here.

def index(request):
    return HttpResponse('<h2>Главная страница</h2>')
#
# def about(request,name,age):
#     return HttpResponse(f'''
# <h2>О пользователе</h2>
# <p>Имя: {name}</p>
# <p>Возраст: {age}</p>
# ''')
#
# def contact(request):
#     return HttpResponse('<h2>Контакты</h2>')
#
# def user(request,name='Undefinde',age=0):
#     return HttpResponse(f'<h2>Имя {name},{age}</h2>')


# def products(request):
#     return HttpResponse("Список товаров")
#
#
# def new(request):
#     return HttpResponse("Новые товары")
#
#
# def top(request):
#     return HttpResponse("Популярные товаров")












# def products(request,id):
#     return HttpResponse(f"Товар {id}")
#
# def coments(request,id):
#     return HttpResponse(f"Коментарий от товаре {id}")
#
# def questions(request,id):
#     return HttpResponse(f"Вопросы о товаре {id}")









# def user(request):
#     age=request.GET.get("age",0)
#     name=request.GET.get("name",'Undefind')
#     return HttpResponse(f'<h2>Имя {name},{age}</h2>')
#
# def about(request):
#     return HttpResponse("About")
#
#
# def contact(request):
#     return HttpResponseRedirect("/about/")
#
# def details(request):
#     return HttpResponsePermanentRedirect('/')










def index(request,id):
    people=[None , 'bob','sam','Tom']
    if id in range(1,len(people)):
        return HttpResponse(people[id])
    else:
        return HttpResponse('Пользователь не найден')

def access(request,age):
    if age not in range(1,111):
        return HttpResponseBadRequest('Неккоректные данные')
    if (age>17):
        return HttpResponse('Доступ запрещен')
    else:
        return HttpResponseForbidden('Иди взрослей')



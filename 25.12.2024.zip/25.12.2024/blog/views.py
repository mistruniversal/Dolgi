from django.shortcuts import render


def my_view(request):
    user_name = "Иван"
    user_age = 25
    is_active = True

    context = {
        'user_name': user_name,
        'user_age': user_age,
        'is_active': is_active,
    }

    return render(request, 'index.html', context)
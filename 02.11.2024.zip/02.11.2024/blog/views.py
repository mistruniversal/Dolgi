from django.shortcuts import render
from django.http import HttpResponse

# Create your views here.


def index(request):
    return HttpResponse("<h1>Главная</h1>")

def catalog(request):
    return HttpResponse("<h1>Каталог</h1>")

def contact(request):
    return HttpResponse("<h1>Контакты</h1>")

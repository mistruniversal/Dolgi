

from Tools.scripts.make_ctype import method
from django.http import HttpResponse
from django.shortcuts import render
from models import Category,Article,Group


# Create your views here.


# Задание1
#     def create(request):
#         Category.objects.create(name='Первая категория')
#         return HttpResponse('Все успешно')


# Задание 2
#     def save(self):
#         Category.objects.create(name='Вторая категория')
#         Category.objects.create(description='Описание второй категории')
#         return HttpResponse('Все успешно')


# Задание 3
# def get(request):
#     category=Article.objects.get(id=4)
#     return HttpResponse('Все успешно')

# Задание 4
# def get(request):
#     category=Article.objects.filter(title='Django 4 для начинающих')
#     return HttpResponse('Все успешно')

# Задание 5
# def all(request):
#     groups=Group.objects.all()
#     return HttpResponse('Все успешно')


# Задание 5


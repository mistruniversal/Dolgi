# from django.template.base import kwarg_re
# from django.urls import path, re_path
# from blog import views
#
# urlpatterns = [
#     path('', views.index),
#     re_path(r'^about/',views.about,kwargs={'name':'Tom','age':38}),
#     re_path(r'^contact/',views.contact),
#     path('user/<str:name>',views.user),
#     path('user/',views.user),
#     path('user/<str:name>/<int:age>',views.user),
#     path('user//<int:age>',views.user)
# ]


from django.urls import path, re_path ,include
from blog import views
from blog.views import products

# urlpatterns = [
#     path('admin/', admin.site.urls),
#     path('user/<str:name>',views.user),
#     path('user/<str:age>',views.user),
#     path('user/',views.user)
# ]

# urlpatterns = [
#     path('', views.user, name='home'),
#     path('about/', views.about, kwargs={"name": 'Tom',"age":37 }),
#     re_path(r'^contact/',views.contact),
#     re_path(r'user/(?P<name>\D+/(?P<age>\d+)',views.user),
#     re_path(r'user/(?P<name>\D+',views.user),
#     re_path(r'user/',views.user),
#
# ]





# productpatterns = [
#     path("", views.products),
#     path("new/", views.new),
#     path("top/", views.top),
# ]
#
#
# urlpatterns = [
#     path("",views.index),
#     path('products/',include(productpatterns))
# ]



productpatterns = [
    # path("", views.products),
    # path("comments/", views.coments),
    # path("question/", views.questions),
    # path("user/", views.user),
]


urlpatterns = [
    # path("",views.index),
    # path("user/", views.user),
    # path("about/", views.about),
    # path('contact/',views.contact),
    # path('details/',views.details)
    # path('products/<int:id>',include(productpatterns))

    path('index/<int:id>/',views.index),
    path('accses/<int:age>/',views.access)
]


"""Параметры представлений
https://127.0.0.1:8000/user/Tom/3
https://127.0.0.1:8000/blog?id=3&name=Tom



request.GET - это словарь переменных GET-запросов
www.google.com/?django=4&python=3

{'django':4,'python':3}
"""
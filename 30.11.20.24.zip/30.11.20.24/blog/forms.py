from django import forms
class UserForm(forms.Form):
    name = forms.CharField(min_length=4, max_length=50)
    age = forms.IntegerField(validators=[MinValueValidator(18)])
    phone = forms.CharField(min_length=11, max_length=20)
    email = forms.EmailField(min_length=10, max_length=50)